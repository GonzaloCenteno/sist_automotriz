<!DOCTYPE html>
<html lang="en">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>FICHA</title>
        <link href="<?php echo e(asset('css/pdf.css')); ?>" rel="stylesheet">
        <style>
            .move-ahead { counter-increment: page 2; position: absolute; visibility: hidden; }
            .pagenum:after { content:' ' counter(page); }
            .footer {position: fixed }
        </style>
    </head>

    <body>
        <table>
            <tbody>
                <tr class="tablaTitulo">
                    <td style="" class="nombreEmpresa" colspan="4"><?php echo e($empresa->emp_titulo); ?></td>
                    <td style="text-align: center" colspan="4"><img src="<?php echo e(asset($empresa->emp_imagen)); ?>" width="150px" height="90px"></td>
                </tr>
                 </tbody>
        </table>
        <table>
            <tbody>
                <tr>
                    <td style="" colspan="2">FACTURAR A</td>
                    <td style="" class="bordeBajo" colspan="2">: <?php echo e($sql->fic_facturara); ?></td>
                    <td style="" colspan="2">FECHA</td>
                    <td style="" class="bordeBajo" colspan="2">: <?php echo e($sql->fic_fecha); ?></td>
                </tr>
                <tr>
                    <td style="" colspan="2">PROPIETARIO</td>
                    <td style="" class="bordeBajo" colspan="6">: <?php echo e($sql->persona->nombreCompleto); ?></td>
                </tr>
                <tr>
                    <td style="text-align: left" colspan="2">DIRECCION</td>
                    <td style="" class="bordeBajo" colspan="6">: <?php echo e($sql->persona->per_direccion); ?></td>
                </tr>
                <tr>
                    <td style="" colspan="2">EMAIL</td>
                    <td style="" class="bordeBajo" colspan="2">: <?php echo e($sql->persona->per_email); ?></td>
                    <td class="ordenTrabajo" style="text-align: center" colspan="4">ORDEN DE TRABAJO :</td>
                </tr>
                <tr>
                    <td style="" colspan="2">TELEFONOS</td>
                    <td style="" class="bordeBajo" colspan="2">: <?php echo e($sql->persona->per_telefonos); ?></td>
                    <td colspan="1"></td>
                    <td class="numOrden" style="text-align: center" colspan="3">N° <?php echo e(str_pad($sql->fic_id,  6, "0",STR_PAD_LEFT)); ?></td>
                </tr>  
                <tr>
                    <td style="" colspan="2">MARCA</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_marca); ?></td>
                    <td style="" colspan="2">PLACA</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_placa); ?></td>
                </tr>
                <tr>
                    <td style="" colspan="2">MODELO</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_modelo); ?></td>
                    <td style="" colspan="2">COLOR</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_color); ?></td>
                </tr>
                <tr>
                    <td style="" colspan="2">KM</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_km); ?></td>
                    <td style="" colspan="2">N° MOTOR</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_nmotor); ?></td>
                </tr>
                <tr>
                    <td style="" colspan="2">AÑO</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_anio); ?></td>
                    <td style="" colspan="2">N° CHASIS</td>
                    <td style="" colspan="2" class="bordeBajo">: <?php echo e($sql->fic_nchasis); ?></td>
                </tr>
            </tbody>
        </table>
        <table class="tablaTrabajosaRealizar">
            <tbody>
                <tr>
                    <td class="tituloTrabajosaRealizar" style="" colspan="8">TRABAJOS A REALIZAR:</td>
                </tr>
                <tr>
                    <td style="" colspan="8"><?php echo $sql->fic_trabajosarealizar; ?></td>
                </tr>
            </tbody>
        </table>
        <table class="tablaInventarioVehiculo">
            <tbody>
                <tr>
                    <td class="textinventario" style="text-align: center" colspan="8"><div id="cabeceraInventario">INVENTARIO VEHICULO</div></td>
                </tr>
                <tr>
                    <td style="text-align: center" colspan="8"><?php echo e($inventario); ?></td>
                </tr>
            </tbody>
        </table>
        <table class="tablaTrabajosaRealizar">
            <tbody>
                <tr>
                    <td class="tituloTrabajosaRealizar" style="text-align: center" colspan="8">OBSERVACIONES</td>
                </tr>
                <tr>
                    <td style="" colspan="8"><?php echo e($sql->fic_observaciones); ?></td>
                </tr>
            </tbody>
        </table>
        <table class="tablaTrabajosaRealizar">
            <tbody>
                <tr>
                    <td class="tituloTrabajosaRealizar" style="text-align: center" colspan="8">NIVEL DE COMBUSTIBLE</td>
                </tr>
                <tr>
                    <td style="text-align: center" colspan="8"><?php echo e($sql->fic_nivelcombustible); ?></td>
                </tr>
            </tbody>
        </table>
        <table>
            <tbody>
                <tr>
                    <td style="text-align: right;" colspan="4"><b><?php echo e($empresa->emp_nombre); ?></b></td>
                    <td style="text-align: left;" colspan="4">: <?php echo e($empresa->emp_direccion); ?></td>
                </tr>
                <tr>
                    <td style="text-align: right;" colspan="4">Cel.</td>
                    <td style="text-align: left;" colspan="4">: <?php echo e($empresa->emp_telefono); ?></td>
                </tr>
                <tr>
                    <td style="text-align: right;" colspan="4">E-mail : <?php echo e($empresa->emp_correo); ?></td>
                    <td style="text-align: left;" colspan="4">Pagina Web : <?php echo e($empresa->emp_web); ?></td>
                </tr>
                <tr>
                    <td style="text-align: right;" colspan="3">Horario de atencion</td>
                    <td style="text-align: left;" colspan="5">: <?php echo e($empresa->emp_horario); ?></td>
                </tr>
                <tr>
                    <td class="textoDescripcion" style="" colspan="8"><?php echo e($empresa->emp_descripcion); ?></td>
                </tr>
            </tbody>
        </table>
    </body>

</html><?php /**PATH C:\xampp\htdocs\sist_automotriz\resources\views/reportes/vw_ficha.blade.php ENDPATH**/ ?>